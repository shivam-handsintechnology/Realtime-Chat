
import React from 'react'

export const NotiFications = () => {
  return (
    <div>
        
    </div>
  )
}
